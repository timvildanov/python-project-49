from brain_games import games, game_logic


def main():
    game_logic.game_engine(games.gcd)


if __name__ == '__main__':
    main()
