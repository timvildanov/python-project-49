#!/usr/bin/env python3

from brain_games.cli import get_user_name_cli


def main():
    get_user_name_cli()


if __name__ == '__main__':
    main()
