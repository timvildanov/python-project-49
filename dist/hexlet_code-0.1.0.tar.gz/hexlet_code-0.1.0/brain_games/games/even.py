from brain_games.game_logic import generate_random_number

GAME_INFO = 'Answer "yes" if number even otherwise answer "no".'


def even_rule():
    """Generate random number and returns the answer"""
    rand_num1 = generate_random_number()
    asking_user_task = f'Question: {rand_num1} '

    task_result = ''
    if rand_num1 % 2 == 0:
        task_result += 'yes'
    else:
        task_result += 'no'
    return asking_user_task, task_result
