from brain_games.games import calc, even, gcd, prime, progression

__all__ = ["calc", "even", "gcd", "prime", "progression"]