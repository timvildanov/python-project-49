from brain_games import games, game_logic


def main():
    game_logic.main_game_loop(games.gcd)


if __name__ == '__main__':
    main()
