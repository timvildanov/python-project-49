from random import randint


def generate_random_number():
    """Generate random number from 1 to 100."""
    return randint(1, 100)
